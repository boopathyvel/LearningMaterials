function FidexDeltaContract() {
    this.web3 = new Web3(web3.currentProvider);
    this.fidexContract = new FidexContract(this.web3);
    this.contract = this.fidexContract.getContract();
}
  
FidexDeltaContract.prototype.deposit = function(ether) {
    ether = '0.5';
    return this.contract.methods.deposit().call({from: this.web3.currentProvider.selectedAddress, gas: 3000000, value: this.web3.utils.toWei(ether)});
}

FidexDeltaContract.prototype.withdraw = function() {
    console.log('withdraw');
}

FidexDeltaContract.prototype.transfer = function() {
    console.log('transfer');
}

FidexDeltaContract.prototype.depositToken = function() {
    console.log('depositToken');
}

FidexDeltaContract.prototype.withdrawToken = function() {
    console.log('withdrawToken');
}

FidexDeltaContract.prototype.transferToken = function() {
    console.log('transferToken');
}


