window.fidex = new FidexDeltaContract();  
document.addEventListener('click', function (event) {
            if (event.target.id === 'deposit'){
                window.fidex.deposit().then(function(data,err) {
                    console.log(data);
                    console.log(err);
                });
            }else if (event.target.id === 'withdraw'){
                window.fidex.withdraw();
            }else if (event.target.id === 'transfer'){
                window.fidex.transfer();
            }else if (event.target.id === 'depositToken'){
                window.fidex.depositToken();
            }else if (event.target.id === 'withdrawToken'){
                window.fidex.withdrawToken();
            }else if (event.target.id === 'transferToken'){
                window.fidex.transferToken();
            }
}, false);

